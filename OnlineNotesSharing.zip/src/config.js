// import Firebase from 'firebase'
// const config = {
//     apiKey: "AIzaSyDk1-UxkdPBphtqhKgC7AUoNk-b2jV2Nfo",
//     authDomain: "online-notes-sharing.firebaseapp.com",
//     databaseURL: "https://online-notes-sharing.firebaseio.com",
//     projectId: "online-notes-sharing",
//     storageBucket: "online-notes-sharing.appspot.com",
//     messagingSenderId: "484329859472",
//     appId: "1:484329859472:web:780052ca33ec6418d9ab15",
//     measurementId: "G-KCXW7R88VP"
// }
// let app = Firebase.initializeApp(config)
// export const db = app.database()

export const firebaseConfig = {
    apiKey: "AIzaSyDk1-UxkdPBphtqhKgC7AUoNk-b2jV2Nfo",
    authDomain: "online-notes-sharing.firebaseapp.com",
    databaseURL: "https://online-notes-sharing.firebaseio.com",
    projectId: "online-notes-sharing",
    storageBucket: "online-notes-sharing.appspot.com",
    messagingSenderId: "484329859472",
    appId: "1:484329859472:web:780052ca33ec6418d9ab15",
    measurementId: "G-KCXW7R88VP"
};
