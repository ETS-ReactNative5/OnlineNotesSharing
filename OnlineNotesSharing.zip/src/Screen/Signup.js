import React, { Component } from 'react';
import { StyleSheet, Text, KeyboardAvoidingView, Image, Alert } from 'react-native';
import { View, Item, Label, Input, Button, Icon, Picker } from "native-base";

import * as firebaseR from "firebase";


export default class Signup extends Component {
    state = {
        passwordVisibility: true,
        role: '',
        email: "",
        pass: "", name: ""
    };

    static navigationOptions = {
        title: "SignUp",

    };

    userSignUp(email, pass) {
        console.log(this.state.email + " " + this.state.pass);
        firebaseR.auth().createUserWithEmailAndPassword(email, pass)
            .then(() => { this.props.navigation.navigate("AuthLoading") })
            .catch(error => {
                Alert.alert(error.message);
            })
        this._signInAsync();
    }

    _signInAsync = async () => {
        await AsyncStorage.setItem('userToken', this.state.email);
        // this.props.navigation.navigate('App');
    };

    render() {

        return (
            <KeyboardAvoidingView behavior="position" style={styles.body}            >
                <View style={{ alignItems: "center" }}>
                    <Image source={require("../../images/logo.png")} style={styles.imgblock} />
                </View>
                <View style={styles.IFeild}>
                    <Item floatingLabel
                        style={{ borderBottomColor: "#d9534a" }}>
                        <Label style={styles.ILabel} >UserName</Label>
                        <Input
                            value={this.state.name}
                            onChangeText={(text) => this.setState({ name: text })}
                        />
                    </Item>
                </View>

                <View style={styles.IFeild}>
                    <Item floatingLabel
                        style={{ borderBottomColor: "#d9534a" }}>
                        <Label style={styles.ILabel} >User Email</Label>
                        <Input
                            value={this.state.email}
                            onChangeText={(text) => this.setState({ email: text })}
                        />
                    </Item>
                </View>

                <View style={styles.IFeild}>
                    <Item floatingLabel style={{ borderBottomColor: "#d9534a" }}>

                        <Label style={styles.ILabel} >User Password</Label>

                        <Input
                            name="password"
                            value={this.state.pass}
                            secureTextEntry={this.state.passwordVisibility}
                            onChangeText={(text) => this.setState({ pass: text })}
                        />
                        <Icon active name="eye" color="#000" onPress={() => {
                            this.setState(prevState => ({
                                passwordIcon: prevState.passwordIcon === 'ios-eye' ? 'ios-eye-off' : 'ios-eye',
                                passwordVisibility: !prevState.passwordVisibility
                            }))
                        }} />


                    </Item>
                </View>
                <View style={styles.IFeild}>
                    <Item picker
                        style={{ borderBottomColor: "#d9534a" }}
                    >
                        <Picker
                            mode="dropdown"
                            style={styles.ILabel}
                            selectedValue={this.state.role}
                            onValueChange={(value) => {
                                this.setState({
                                    role: value
                                })
                            }
                            }
                        >
                            <Picker.Item label="Student" value="Student" />
                            <Picker.Item label="Teacher" value="Teacher" />
                        </Picker>
                    </Item>
                </View>

                <Button full rounded danger style={styles.ButtonI} onPress={() => this.userSignUp(this.state.email, this.state.pass)}>
                    <Text style={{ fontSize: 24, color: "white" }}>SignUp</Text>
                </Button>

                <View style={styles.IFeild, { flexDirection: "row", justifyContent: "center" }}>
                    <Text style={{ fontSize: 16, }} >Already having an account?</Text>
                    <Text style={{ fontWeight: "bold", fontSize: 16 }} onPress={() => this.props.navigation.navigate('LogIn')}>Sign in</Text>
                </View>
            </KeyboardAvoidingView>
        );
    }
}
const styles = StyleSheet.create(
    {
        body: {
            flex: 1,
            backgroundColor: "#fff",
            justifyContent: "flex-start",
            padding: 10, alignItems: "center"
        }, IFeild: {
            padding: 7.5, fontSize: 22, color: "red", width: 500
        }, ILabel: {
            fontSize: 20, color: "grey"
        }, ButtonI: {
            margin: 20, justifyContent: "center"
        },

        form: {
            // justifyContent: "center",
            flex: 90,
            alignItems: "center"
        },
        head: {
            backgroundColor: '#1e85c9', justifyContent: "center",
            flex: 10, alignItems: "center"
        },
        imgblock: {
            backgroundColor: '#1e85c9',
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 100, width: 200, height: 200,
            marginBottom: 50,
            marginTop: 50,
        },
        inputContainer: {
            backgroundColor: '#1e85c9', width: 300
            , marginBottom: 20, padding: 5, fontSize: 20
        },
        inputContainer2: {
            backgroundColor: '#1e85c9', width: 300
            , marginBottom: 20, padding: 5, fontSize: 20,
            flexDirection: "row", alignItems: "center", justifyContent: "space-between"
        },
        radioContainer: {
            backgroundColor: '#1e85c9', width: 300, color: "#777",
            flexDirection: "row", marginBottom: 40, padding: 5, fontSize: 20,
            justifyContent: "space-around",
            alignItems: "center",
        },
        btnLogin: {
            backgroundColor: '#1e85c9',
            width: 150, height: 40,
            marginBottom: 50, padding: 7,
            justifyContent: "center", alignItems: "center"
        }
    }
)