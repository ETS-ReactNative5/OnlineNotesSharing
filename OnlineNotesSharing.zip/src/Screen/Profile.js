import React, { Component } from 'react';
import {
    StyleSheet,
    View,
    Text, FlatList,
    TextInput,
    Button, TouchableOpacity,
    Image
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import MHeader from '../Component/hHeader';

export default class Signup extends Component {
    state = {
        checked: 'Student',Screen:"Profile"
    };

    render() {

        return (
            <View style={styles.body}>
                <MHeader SName={this.state.Screen}/>

                <View style={styles.form}>
                    <View style={styles.outer}>
                        <View style={styles.inner}>
                            <Image style={styles.imgblock} source={require("../../images/user.png")} />
                            <Text style={styles.text}>NAME</Text>
                            <Text style={styles.smtext}>Type</Text>
                        </View>
                        <View style={styles.textblock}>
                            <Icon name="upload" style={{ marginRight: 30, marginLeft: 30 }} color='#fff' size={50} />
                            <View style={styles.rating}>
                                <Icon name="star" style={{ marginRight: 5 }} color='#FBFE38' size={15} />
                                <Icon name="star" style={{ marginRight: 5 }} color='#FBFE38' size={15} />
                                <Icon name="star" style={{ marginRight: 5 }} color='#FBFE38' size={15} />
                                <Icon name="star" style={{ marginRight: 5 }} color='#FBFE38' size={15} />
                                <Icon name="star" style={{ marginRight: 5 }} color='#FBFE38' size={15} />
                            </View>
                        </View>
                        {/* //inner */}
                    </View>
                    {/* //outer */}
                    <Button style={styles.btnLogin} title="Edit"
                        onPress={() => this.props.navigation.navigate("editProfileScreen")} />
                </View>
                {/* //form */}
                {/* <Bottem/> */}
                {/* //nav */}
            </View >// body

        );
    }
}
const styles = StyleSheet.create(
    {
        body: {
            backgroundColor: 'rgb(227, 227, 227)',
            flex: 1
        },
        // :{
        //   fontSize:30,color:'#fff'
        // },
        form: {
            flex: 80,
        },
        head: {
            backgroundColor: '#1e85c9',
            justifyContent: "space-between",
            alignItems: "center", flexDirection: "row",
            height: 60
        },
        imgblock: {
            backgroundColor: '#cccc',
            justifyContent: "center",
            alignItems: "center",
            borderRadius: 100,
            width: 150, height: 150,
            marginBottom: 10,
            marginLeft: 10,
        },
        textblock: {
            alignItems: "center",
            flexDirection: "row",
            justifyContent: "center",
            marginLeft: 50
        },
        rating: {
            flexDirection: "row",
            color: '#fff'
        },
        inner: {
            // flexDirection:"row"
            justifyContent: "center",
            alignItems: "center",
            marginLeft: 50
        },
        inputContainer: {
            backgroundColor: '#1e85c9',
            marginBottom: 40,
            padding: 5,
            flex: 1, flexDirection: "row"
        },
        btnLogin: {
            fontSize: 30,
            color: '#444',

        },
        navbar: {
            backgroundColor: '#1e85c9',
            flex: 6, flexDirection: "row", justifyContent: "space-around"
            , alignItems: "center"
        },
        text: {
            fontSize: 20
        },
        smtext: {
            fontSize: 16
        },
        stext: {
            fontSize: 17
        },
        outer: {
            flexDirection: "row", backgroundColor: '#aaa',
            paddingBottom: 30,
            paddingTop: 30,
        }
    }
)