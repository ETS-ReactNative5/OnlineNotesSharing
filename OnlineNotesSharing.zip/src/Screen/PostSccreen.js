import React, { Component } from 'react';
import { FlatList, Image, AsyncStorage,View } from 'react-native';
import { Container, Content, Card, CardItem, Thumbnail, Text, Button, Icon, Left, Body, Right } from 'native-base';
import MHeader from "../Component/hHeader"
import * as firebaseR from "firebase";

export default class Home extends Component {

    constructor() {
        super();
        this.state = {
            Screen: "Upload"
        };
    }

    render() {

        return (
            <Container >
                <MHeader SName={this.state.Screen} />
                <View style={{ alignItems: "center",marginTop:100 }}>
                    <Text uppercase style={{ fontSize: 24, marginBottom: 20 }}>Upload Notes</Text>
                    <View padder >
                        <Button style={{ fontSize: 24, margin: 20 }}>
                            <Text style={{ fontSize: 24, }}>Create PDF</Text>
                            <Icon name="camera" style={{ fontSize: 24 }} />
                        </Button>
                        <Button style={{ fontSize: 24, margin: 20 }}>
                            <Text style={{ fontSize: 24, }}>Select PDF</Text>
                            <Icon name="md-document" style={{ fontSize: 24 }} />
                        </Button>
                    </View>
                </View>
            </Container>
        );
    }
}